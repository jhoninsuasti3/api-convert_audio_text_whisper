from django.apps import AppConfig


class TranscripcionAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'transcripcion_app'
